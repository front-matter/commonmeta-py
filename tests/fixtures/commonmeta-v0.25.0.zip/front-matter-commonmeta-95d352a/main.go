/*
Copyright © 2024 Front Matter <info@front-matter.io>
*/
package main

import (
	"github.com/front-matter/commonmeta/cmd"
)

func main() {
	cmd.Execute()
}
